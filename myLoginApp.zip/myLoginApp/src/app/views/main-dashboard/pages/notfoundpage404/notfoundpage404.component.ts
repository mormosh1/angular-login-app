import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-notfoundpage404',
  templateUrl: './notfoundpage404.component.html',
  styleUrls: ['./notfoundpage404.component.scss']
})
export class Notfoundpage404Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
