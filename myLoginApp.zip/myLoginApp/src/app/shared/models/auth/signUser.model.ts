export interface signUser {
  email: string,
  password: string,
  full_name?: string
}
