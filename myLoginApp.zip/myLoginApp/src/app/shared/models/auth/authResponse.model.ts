export interface authResponse {
  token: string,
  id: number
}
